import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.io.File;

public class ImgViewer extends JFrame implements ActionListener {

    JTextField widthTextField;
    JTextField heightTextField;
    JTextField brightnessTextField;
    File file;
    JFileChooser fileChooser = new JFileChooser();
    float brightenFactor = 1;
   
    Color backgroundColor = new Color(238, 238, 238);
    Color buttonColor = new Color(255, 255, 255);
    int width;
    int height;
    private Image img;
    int newWidth = 0;
    int newHeight = 0;
    JButton resizeButton = new JButton("Resize");


    public ImgViewer() {
        this.setTitle("Image Viewer");
        this.setSize(700, 300);
        this.setVisible(true);
        this.setResizable(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.selectFileButton.setBackground(buttonColor);
        this.showImageButton.setBackground(buttonColor);
        this.resizeButton.setBackground(buttonColor);
        this.grayscaleButton.setBackground(buttonColor);
        this.brightnessButton.setBackground(buttonColor);
        this.closeButton.setBackground(buttonColor);
        this.showResizeButton.setBackground(buttonColor);
        this.showBrightnessButton.setBackground(buttonColor);
        this.backButton.setBackground(buttonColor);
        mainPanel();
    }

    public void mainPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(backgroundColor);

        JPanel btn = new JPanel();
        btn.setLayout(new GridLayout(3, 2));
        int buttonHeight = 50;
        int buttonWidth = 300;
        btn.setBounds((700 - buttonWidth * 2) / 2, (300 - buttonHeight * 2) / 2, (buttonWidth * 2), (buttonHeight * 2));

        JLabel label = new JLabel("Image Viewer");
        label.setBounds(312, 50, 75, 30);

        btn.add(this.showImageButton);
        btn.add(this.brightnessButton);
        btn.add(this.grayscaleButton);
        btn.add(this.resizeButton);
        btn.add(this.closeButton);
        btn.add(this.selectFileButton);

        this.brightnessButton.addActionListener(this);
        this.grayscaleButton.addActionListener(this);
        this.closeButton.addActionListener(this);
        this.selectFileButton.addActionListener(this);
        this.showImageButton.addActionListener(this);
        this.resizeButton.addActionListener(this);

        panel.add(label);
        panel.add(btn);

        this.add(panel);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == resizeButton) {
            this.resizePanel();
        } else if (e.getSource() == showImageButton) {
            this.showOriginalImage();
        } else if (e.getSource() == grayscaleButton) {
            this.grayScaleImage();
        } else if (e.getSource() == showResizeButton) {
            String widthText = this.widthTextField.getText();
            String heightText = this.heightTextField.getText();
            if (widthText.isEmpty() || heightText.isEmpty()) {
                JOptionPane.showMessageDialog(null, "width and height is null");
                return;
            }
            int width = Integer.parseInt(this.widthTextField.getText());
            int height = Integer.parseInt(this.heightTextField.getText());
            this.showResizeImage(height, width);
        } else if (e.getSource() == brightnessButton) {
            this.brightnessPanel();
        } else if (e.getSource() == showBrightnessButton) {
            String brightnessText = this.brightnessTextField.getText();
            if (brightnessText.isEmpty()) {
                JOptionPane.showMessageDialog(null, "brightness is null");
                return;
            }
            float factor = Float.parseFloat(this.brightnessTextField.getText());
            this.showBrightnessImage(factor);
            this.brightenFactor = factor;
        } else if (e.getSource() == selectFileButton) {
            this.chooseFileImage();
        } else if (e.getSource() == closeButton) {
            this.dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
        }
    }

    public void chooseFileImage() {
        int resule = fileChooser.showOpenDialog(null);
        if (resule == JFileChooser.APPROVE_OPTION) {
            file = fileChooser.getSelectedFile();
        }
        ImageIcon imageIcon = new ImageIcon(file.getAbsolutePath());
        this.height = imageIcon.getIconHeight();
        this.width = imageIcon.getIconWidth();
        double aspectRatio = (double) this.width / this.height;
        if (this.width > 1500) {
            newHeight = (int) (newWidth / aspectRatio);
            newWidth = 1500;
        }
        if (this.height > 800) {
            newWidth = (int) (newHeight * aspectRatio);
            newHeight = 800;
        }
        this.img = imageIcon.getImage().getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
    }

    public void showOriginalImage() {
        ImageActions.showOriginalImage(this.img, this.newWidth, this.newHeight, this.backgroundColor, this);
    }

    public void grayScaleImage() {
        ImageActions.grayScaleImage(this.img, this.newWidth, this.newHeight, this.backgroundColor, this);
    }

    public void brightnessPanel() {
        ImageActions.brightnessPanel(this);
    }

    public void showBrightnessImage(float factor) {
        ImageActions.showBrightnessImage(this.img, this.newWidth, this.newHeight, this.backgroundColor, factor, this);
    }

    public void resizePanel() {
        ImageActions.resizePanel(this);
    }

    public void showResizeImage(int height, int width) {
        ImageActions.showResizeImage(this.img, width, height, this.backgroundColor, this);
    }

    JButton selectFileButton = new JButton("Choose Image");
    JButton showImageButton = new JButton("Show Image");
    JButton grayscaleButton = new JButton("Grayscale");
    JButton brightnessButton = new JButton("Brightness");
    JButton closeButton = new JButton("Exit");
    JButton showResizeButton = new JButton("Show Resized Image");
    JButton showBrightnessButton = new JButton("Show Brightness Image");
    JButton backButton = new JButton("Back");


}
