import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.image.RescaleOp;

public class ImageActions {

    public static void showOriginalImage(Image img, int newWidth, int newHeight, Color backgroundColor, ImgViewer parentFrame) {
        if (img == null) {
            JOptionPane.showMessageDialog(null, "image null");
            return;
        }
        JFrame t = new JFrame();
        JPanel p = new JPanel();
        p.setBackground(backgroundColor);
        p.setLayout(null);
        parentFrame.backButton.setBounds(10, 10, 100, 30);
        p.add(parentFrame.backButton);
        parentFrame.backButton.addActionListener(_ -> {
            t.dispose();
            parentFrame.getContentPane().removeAll();
            parentFrame.mainPanel();
            parentFrame.revalidate();
            parentFrame.repaint();
        });
        ImageIcon newImage = new ImageIcon(img);
        JLabel label = new JLabel(newImage);
        label.setBounds((1500 - newWidth) / 2, (800 - newHeight) / 2, newWidth, newHeight);
        p.add(label);
        t.setTitle("Image Viewer");
        t.setSize(1500, 800);
        t.setVisible(true);
        t.setResizable(true);
        t.add(p);
        t.setContentPane(p);
    }

    public static void grayScaleImage(Image img, int newWidth, int newHeight, Color backgroundColor, ImgViewer parentFrame) {
        if (img == null) {
            JOptionPane.showMessageDialog(null, "image null");
            return;
        }
        JFrame t = new JFrame();
        JPanel p = new JPanel();
        p.setBackground(backgroundColor);
        p.setLayout(null);
        parentFrame.backButton.setBounds(10, 10, 100, 30);
        p.add(parentFrame.backButton);
        parentFrame.backButton.addActionListener(_ -> {
            t.dispose();
            parentFrame.getContentPane().removeAll();
            parentFrame.mainPanel();
            parentFrame.revalidate();
            parentFrame.repaint();
        });
        ImageIcon newImage = new ImageIcon(img);
        Image image = newImage.getImage();
        BufferedImage bufferedImage = new BufferedImage(image.getWidth(null), image.getHeight(null), BufferedImage.TYPE_BYTE_GRAY);
        Graphics g = bufferedImage.getGraphics();
        g.drawImage(image, 0, 0, null);
        g.dispose();
        ImageIcon grayImage = new ImageIcon(bufferedImage);
        JLabel label = new JLabel(grayImage);
        label.setBounds((1500 - newWidth) / 2, (800 - newHeight) / 2, newWidth, newHeight);
        p.add(label);
        t.setTitle("Image Viewer");
        t.setSize(1500, 800);
        t.setVisible(true);
        t.setResizable(true);
        t.add(p);
        t.setContentPane(p);
    }

    public static void brightnessPanel(ImgViewer parentFrame) {
        JPanel brightnessPanel = new JPanel();
        JFrame brightnessFrame = new JFrame();
        brightnessPanel.setLayout(null);
        brightnessPanel.setBackground(parentFrame.backgroundColor);
        parentFrame.brightnessTextField = new JTextField();
        JLabel brightnessLabel = new JLabel("Brightness");
        parentFrame.backButton.setBounds(250, 200, 200, 30);
        parentFrame.brightnessTextField.setBounds(350, 100, 100, 30);
        brightnessLabel.setBounds(250, 100, 100, 30);
        parentFrame.showBrightnessButton.setBounds(250, 150, 200, 30);
        brightnessPanel.add(parentFrame.brightnessTextField);
        brightnessPanel.add(parentFrame.backButton);
        brightnessPanel.add(parentFrame.showBrightnessButton);
        brightnessPanel.add(brightnessLabel);
        parentFrame.showBrightnessButton.addActionListener(parentFrame);
        parentFrame.backButton.addActionListener(_ -> {
            brightnessFrame.setVisible(false);
            parentFrame.getContentPane().removeAll();
            parentFrame.mainPanel();
            parentFrame.revalidate();
            parentFrame.repaint();
        });
        parentFrame.getContentPane().removeAll();
        parentFrame.add(brightnessPanel);
        parentFrame.revalidate();
        parentFrame.repaint();
    }

    public static void showBrightnessImage(Image img, int newWidth, int newHeight, Color backgroundColor, float factor, ImgViewer parentFrame) {
        if (img == null) {
            JOptionPane.showMessageDialog(null, "image null");
            return;
        }
        JFrame t = new JFrame();
        JPanel p = new JPanel();
        p.setBackground(backgroundColor);
        p.setLayout(null);
        parentFrame.backButton.setBounds(10, 10, 100, 30);
        p.add(parentFrame.backButton);
        parentFrame.backButton.addActionListener(_ -> {
            t.dispose();
            parentFrame.getContentPane().removeAll();
            parentFrame.brightnessPanel();
            parentFrame.revalidate();
            parentFrame.repaint();
        });
        Image newImg = img;
        BufferedImage bufferedImage = new BufferedImage(newImg.getWidth(null), newImg.getHeight(null), BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = bufferedImage.createGraphics();
        g.drawImage(newImg, 0, 0, null);
        RescaleOp op = new RescaleOp(factor, 0, null);
        bufferedImage = op.filter(bufferedImage, null);
        ImageIcon newImage = new ImageIcon(bufferedImage);
        JLabel label = new JLabel(newImage);
        label.setBounds((1500 - newWidth) / 2, (800 - newHeight) / 2, newWidth, newHeight);
        p.add(label);
        p.setSize(1500, 800);
        t.setTitle("Image Viewer");
        t.setSize(1500, 800);
        t.setVisible(true);
        t.setResizable(true);
        t.add(p);
    }

    public static void resizePanel(ImgViewer parentFrame) {
        JPanel resizePanel = new JPanel();
        resizePanel.setLayout(null);
        resizePanel.setBackground(parentFrame.backgroundColor);
        parentFrame.widthTextField = new JTextField();
        parentFrame.heightTextField = new JTextField();
        JLabel widthLabel = new JLabel("Width");
        JLabel heightLabel = new JLabel("Height");
        parentFrame.showResizeButton.setBounds(250, 150, 200, 30);
        parentFrame.backButton.setBounds(250, 200, 200, 30);
        widthLabel.setBounds(250, 100, 100, 30);
        heightLabel.setBounds(250, 50, 100, 30);
        parentFrame.widthTextField.setBounds(350, 100, 100, 30);
        parentFrame.heightTextField.setBounds(350, 50, 100, 30);
        resizePanel.add(parentFrame.widthTextField);
        resizePanel.add(parentFrame.heightTextField);
        resizePanel.add(widthLabel);
        resizePanel.add(heightLabel);
        resizePanel.add(parentFrame.showResizeButton);
        resizePanel.add(parentFrame.backButton);
        parentFrame.showResizeButton.addActionListener(parentFrame);
        parentFrame.backButton.addActionListener(_ -> {
            resizePanel.setVisible(false);
            parentFrame.getContentPane().removeAll();
            parentFrame.mainPanel();
            parentFrame.revalidate();
            parentFrame.repaint();
        });
        parentFrame.getContentPane().removeAll();
        parentFrame.add(resizePanel);
        parentFrame.revalidate();
        parentFrame.repaint();
    }

    public static void showResizeImage(Image img, int width, int height, Color backgroundColor, ImgViewer parentFrame) {
        if (img == null) {
            JOptionPane.showMessageDialog(null, "image null");
            return;
        }
        JFrame t = new JFrame();
        JPanel p = new JPanel();
        p.setBackground(backgroundColor);
        p.setLayout(null);
        parentFrame.backButton.setBounds(10, 10, 100, 30);
        p.add(parentFrame.backButton);
        parentFrame.backButton.addActionListener(_ -> {
            t.dispose();
            parentFrame.getContentPane().removeAll();
            parentFrame.resizePanel();
            parentFrame.revalidate();
            parentFrame.repaint();
        });
        Image newImg = img.getScaledInstance(width, height, Image.SCALE_SMOOTH);
        ImageIcon newImage = new ImageIcon(newImg);
        JLabel label = new JLabel(newImage);
        label.setBounds((1500 - width) / 2, (800 - height) / 2, width, height);
        p.add(label);
        p.setSize(1500, 800);
        t.setTitle("Image Viewer");
        t.setSize(1500, 800);
        t.setVisible(true);
        t.setResizable(true);
        t.add(p);
    }
}
